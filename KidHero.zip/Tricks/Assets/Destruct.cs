﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destruct : MonoBehaviour {

	private int qtdPontosComidaRuim;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {


	}

	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.CompareTag ("Comida") && other.GetComponent<ComidaScript> ().qntdPontos < 0) 
		{
			GameObject.FindObjectOfType<PlayerControl> ().score += 5; 
		}
		if(other.CompareTag("Comida"))
		{
			Destroy (other.gameObject);
		}


	}

}

