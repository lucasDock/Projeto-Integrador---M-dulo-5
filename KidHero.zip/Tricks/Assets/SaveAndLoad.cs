﻿using UnityEngine;
using System.Collections.Generic;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using UnityEngine.SceneManagement;


public class SaveAndLoad : MonoBehaviour
{
    public static SaveAndLoad instance;

    void Awake()
    {
        instance = this;
    }

    public void Save(string _userID, int _userScore)
    {
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/" + _userID + ".luc");
        SceneStatus data = new SceneStatus();

        data.userScore = _userScore;

        bf.Serialize(file, data);
        file.Close();
    }

    public int Load(string _userID)
    {
        if (File.Exists(Application.persistentDataPath + "/" + _userID + ".luc"))
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(Application.persistentDataPath + "/" + _userID + ".luc", FileMode.Open);
            SceneStatus data = (SceneStatus)bf.Deserialize(file);
			int scoreLoaded = data.userScore;
            file.Close();
            return scoreLoaded;

        }
        else
        {
            print("Arquivo não encontrado.");
			return 0;
        }
    }
}

[Serializable]
class SceneStatus
{
    public int userScore = 0;
}
