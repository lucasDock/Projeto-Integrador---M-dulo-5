﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ComidaController : MonoBehaviour {

	[SerializeField] private GameObject comida = null;
	[SerializeField] private Transform alturaMax = null;
	[SerializeField] private Transform alturaMin = null;

	private float delay = 1;
	private float delayAumentarSpeed = 20;
	private float foodSpeed = 4;

	void Start () 
	{
		alturaMax = GameObject.FindGameObjectWithTag ("AlturaMax").transform;
		alturaMin = GameObject.FindGameObjectWithTag ("AlturaMin").transform;

		StartCoroutine (CriarComidaAutomaticamente ());
		StartCoroutine (DelayAumentarSpeed ());
	}

	void Update () {
		
	}

	void CriarComida()
	{
		GameObject novaComida = Instantiate (comida, new Vector3 (alturaMax.position.x, Random.Range (alturaMin.position.y, alturaMax.position.y), 0), Quaternion.identity);
		novaComida.GetComponent<ComidaScript> ().speed = foodSpeed;
	}

	IEnumerator CriarComidaAutomaticamente()
	{
		yield return new WaitForSeconds (delay);
		foodSpeed = foodSpeed + 0.02f;

		CriarComida ();

		StartCoroutine (CriarComidaAutomaticamente ());
	}

	IEnumerator DelayAumentarSpeed()
	{
		yield return new WaitForSeconds (delayAumentarSpeed);

		foodSpeed = foodSpeed + 0.02f;
		StartCoroutine (DelayAumentarSpeed ());
	}


}
