﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlarGERAL : MonoBehaviour {


	public GameObject playAgain = null;
	public GameObject backToMenu = null;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}



}
