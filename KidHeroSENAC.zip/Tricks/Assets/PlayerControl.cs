﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerControl : MonoBehaviour {

	[SerializeField] private float speed = 0;
	[SerializeField] private int hp = 100;
	[SerializeField] private Slider hpBar = null;
	[SerializeField] private Image fillColor = null;
	[SerializeField] private Text scoreText = null;
	[SerializeField] private GameObject lost = null;
	[SerializeField] private Text pntFinal = null;
	[SerializeField] private GameObject comidaControllerPrefab;

	public bool gameOver = false;

	public int score;
	private bool pressedUp = false;
	private bool pressedDown = false;
	private bool blockUp = false;
	private bool blockDown = false;



	void Start () {

		score = 0;
		scoreText.text = "Score: " + score;
	}
	
	void Update () {

		if (!gameOver) {
			if (pressedUp) {
				if (!blockUp) {
					transform.Translate (new Vector3 (0, 1, 0) * speed * Time.deltaTime);
				}
			} else if (pressedDown) {
				if (!blockDown) {
					transform.Translate (new Vector3 (0, -1, 0) * speed * Time.deltaTime);
				}
			}
			if (transform.localPosition.y > -636) {
				blockUp = true;
			} else {
				blockUp = false;
			}

			if (transform.localPosition.y < -644) {
				blockDown = true;
			} else {
				blockDown = false;
			}	

			scoreText.text = "Score: " + score;
		}

	}

	public void PressMoveUp()
	{
		pressedUp = true;
	}

	public void ReleaseMoveUp()
	{
		pressedUp = false;
	}

	public void PressMoveDown()
	{
		pressedDown = true;
	}

	public void ReleaseMoveDown()
	{
		pressedDown = false;
	}

	public void OnTriggerEnter2D(Collider2D other)
	{
		if(other.CompareTag("Comida"))
		{
			hp = hp + other.GetComponent<ComidaScript> ().qntdPontos;

			if(hp > 100)
			{
				hp = 100;
			}

			hpBar.value = hp / 100f;

			if(hpBar.value < 0.7f && hpBar.value >= 0.4f)
			{
				fillColor.color = Color.yellow;
			}
			else if(hpBar.value < 0.4f)
			{
				fillColor.color = Color.red;
			}
			else
			{
				fillColor.color = Color.green;
			}


			if (other.GetComponent<ComidaScript>().qntdPontos >0)
			{

				score = score + other.GetComponent<ComidaScript> ().qntdPontos;

			}

			Destroy (other.gameObject);

		}



		if (hpBar.value < 0.1f)
		{
			print ("morre");
			if (score > SaveAndLoad.instance.Load (FindObjectOfType<ControladorFacebook> ().userID)) {
				SaveAndLoad.instance.Save (FindObjectOfType<ControladorFacebook> ().userID, score);
			}
			GameObject[] listComida = GameObject.FindGameObjectsWithTag ("Comida");

			for (int i = 0; i < listComida.Length; i++) {
				Destroy (listComida [i]);
			}

			Destroy (FindObjectOfType<ComidaController>().gameObject);

			pntFinal.text = scoreText.text;
			lost.SetActive (true);
			gameOver = true;
		}
	}

	public void ResetGame()
	{
		hp = 100;
		hpBar.value = hp / 100f;

		if (hpBar.value < 0.7f && hpBar.value >= 0.4f) {
			fillColor.color = Color.yellow;
		} else if (hpBar.value < 0.4f) {
			fillColor.color = Color.red;
		} else {
			fillColor.color = Color.green;
		}
		score = 0;


		Instantiate (comidaControllerPrefab, Vector3.zero, Quaternion.identity);

	gameOver = false;
	lost.SetActive (false);
	}


}






