﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ComidaScript : MonoBehaviour {

	public int qntdPontos;
	public float speed;

	[SerializeField] List<Sprite> listaSprites = null;
	[SerializeField] List<int> listaPontuacao = null;


	void Start () 
	{
		int random = Random.Range (0, listaSprites.Count);
		GetComponent<SpriteRenderer> ().sprite = listaSprites [random];
		qntdPontos = listaPontuacao [random];
	}
	

	void Update () 
	{
		
		transform.Translate (new Vector3 (-1, 0, 0) * speed * Time.deltaTime);
	}
}
