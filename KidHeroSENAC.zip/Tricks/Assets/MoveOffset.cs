﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveOffset : MonoBehaviour {


	private Material currentMaterial;
	public float speed;


	void Start () {

		currentMaterial = GetComponent<MeshRenderer> ().material;

	}

	void Update () 
	{
		if (!FindObjectOfType<PlayerControl> ().gameOver) {
			currentMaterial.mainTextureOffset = new Vector2 (currentMaterial.mainTextureOffset.x + speed, 0);
		}
	}


}
