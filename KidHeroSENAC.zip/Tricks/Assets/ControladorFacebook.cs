﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Facebook.Unity;
using UnityEngine.UI;
using Facebook.MiniJSON;

public class ControladorFacebook : MonoBehaviour 
{
	public GameObject UIFBIsLoggedIn;
	public GameObject UIFBNotLoggedIn;
	public GameObject UIFBAvatar;
	public GameObject UIFBUsarName;
	public GameObject BtnJogar;
	public Text userScore;

	public Text idUsuarioText;
	public string userID;

	private Dictionary<string, string> profile = null;




	private void Awake()
	{
		if (!FB.IsInitialized)
		{
			FB.Init();
		} 
		else 
		{
			FB.ActivateApp();
		}

	}

	public void SalvarJogo()
	{
		SaveAndLoad.instance.Save (userID,0);
	}

	void OnApplicationPause(bool pauseStatus)
	{
		if (pauseStatus)
			{
				FB.LogOut();
			}
	}

	public void LogIn()
	{
		FB.LogInWithReadPermissions (callback:AuthCallback);


	}

	private void OnLogIn (ILoginResult result)
	{
		if (FB.IsLoggedIn) 
		{
			AccessToken token = AccessToken.CurrentAccessToken;

		} 
		else
			Debug.Log ("Login Cancelado");
	}

	void AuthCallback(IResult result)
	{
		if (FB.IsLoggedIn)
		{
			Debug.Log ("Login com sucesso");
			ScreenOrder (true);
		} 
		else
			Debug.Log ("Login falhou");
		ScreenOrder (false);

	}

	void ScreenOrder (bool isLoggedIn)
	{
		if (isLoggedIn)
		{
			FB.API (Util.GetPictureURL ("me", 128, 128), HttpMethod.GET, ProfilePictureCallback);
			FB.API ("/me?friends=id,first_name", HttpMethod.GET, faceUserNameCallback);
		}


	}


	private void faceUserNameCallback(IResult result)
	{
		if (result.Error != null)
		{
			Debug.Log("Erro ao coletar Nome de Perfil");

			FB.API ("/me?fields=id,first_name", HttpMethod.GET, faceUserNameCallback);
			return;
		}

		profile = Util.DeserializeJSONProfile (result.RawResult);
		Text UserMsg = UIFBUsarName.GetComponent<Text> ();

		userID = profile ["id"];

		if (profile ["id"] == "1361354653945711") {
			UserMsg.text = "Olá, Gustavo";
		} else 
		{
			UserMsg.text = "Olá, Lucas";
		}

		userScore.enabled = true;
		userScore.text = "High Score: " + SaveAndLoad.instance.Load (userID);
		BtnJogar.SetActive (true);

	}


	private void ProfilePictureCallback(IGraphResult result)
	{
		UIFBAvatar.SetActive (true);
		if (result.Error != null)
		{
			Debug.Log("problem with getting profile picture");

			FB.API(Util.GetPictureURL("me", 128, 128), HttpMethod.GET, ProfilePictureCallback);
			return;
		}

		Image UserAvatar = UIFBAvatar.GetComponent<Image>();
		UserAvatar.sprite = Sprite.Create(result.Texture, new Rect(0, 0, 128, 128), new Vector2(0, 0));


	}



	public void Share()
	{
		FB.ShareLink (contentTitle:"Joguei KidHero no SmartPhone!", 
			contentURL:new System.Uri("https://github.com/lucasDock/ProjetoIntegrador2017"),
			contentDescription:"Minha pontuação foi: " + userScore,
			callback:OnShare);
	}

	private void OnShare(IShareResult result)
	{
		
		if (result.Cancelled || !string.IsNullOrEmpty (result.Error))
		{
			Debug.Log ("Erro de compartilhar link: " + result.Error);
		} 
		else if (!string.IsNullOrEmpty (result.PostId)) 
		{
			Debug.Log (result.PostId);
		} 
		else
			Debug.Log ("Compartilhado com sucesso");
	}

}
